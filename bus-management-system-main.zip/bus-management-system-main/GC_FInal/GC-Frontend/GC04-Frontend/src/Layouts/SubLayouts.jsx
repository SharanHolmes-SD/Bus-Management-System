import React from 'react'
import HeroSub from '../Component/HeroSub'

function SubLayouts() {
  return (
    <HeroSub/>
  )
}

export default SubLayouts
