import React from 'react'
import About from '../Component/About'

function AboutLayout() {
  return (
    <About/>
  )
}

export default AboutLayout
