import React from 'react'
import BusRoutes from '../Component/BusRoutes'
function BusRouteLayout() {
  return (
    <BusRoutes/>
  )
}

export default BusRouteLayout
