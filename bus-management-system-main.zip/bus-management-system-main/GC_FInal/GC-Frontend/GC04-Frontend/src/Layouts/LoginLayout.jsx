import React from 'react'
import Login from '../Component/Login'

function LoginLayout() {
  return (
   <Login/>
  )
}

export default LoginLayout
